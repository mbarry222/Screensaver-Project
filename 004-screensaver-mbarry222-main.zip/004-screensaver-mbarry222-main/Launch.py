import pygame
import sys
import random
import pygwidgets
from Particle import Sun, MovingObject

pygame.init()

pygame.mixer.music.load('ocean-wave-1.mp3')
pygame.mixer.music.play(-1)

BLACK = (0, 0, 0)
screen_info = pygame.display.Info()
WINDOW_WIDTH = screen_info.current_w
WINDOW_HEIGHT = screen_info.current_h
FRAMES_PER_SECOND = 30

window = pygame.display.set_mode((WINDOW_WIDTH, WINDOW_HEIGHT), pygame.FULLSCREEN)
clock = pygame.time.Clock()


sun = Sun(window, WINDOW_WIDTH, WINDOW_HEIGHT, (WINDOW_WIDTH // 2, WINDOW_HEIGHT // 4), (255, 165, 0), 50)

#buttons
change_sun_color_button = pygwidgets.TextButton(window, (20, 20), 'Change Sun Color')
reset_button = pygwidgets.TextButton(window, (20, 80), 'Reset Sun')
exit_button = pygwidgets.TextButton(window, (20, 140), 'Exit')

sun_colors = [(255, 165, 0), (255, 255, 0), (255, 192, 203), (64, 224, 208)]
current_color_index = 0

# Game loop
running = True
while running:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
        elif event.type == pygame.KEYDOWN:
            if event.key == pygame.K_ESCAPE:
                running = False
        elif change_sun_color_button.handleEvent(event):
            current_color_index = (current_color_index + 1) % len(sun_colors)
            sun.color = sun_colors[current_color_index]
        elif reset_button.handleEvent(event):
            sun.x, sun.y = WINDOW_WIDTH // 2, WINDOW_HEIGHT // 4
        elif exit_button.handleEvent(event):
            running = False

    sun.update()

    background_image = pygame.image.load('bora-bora.jpg').convert()
    background_image = pygame.transform.scale(background_image, (WINDOW_WIDTH, WINDOW_HEIGHT))

    window.blit(background_image, (0, 0))

    sun.draw()
    change_sun_color_button.draw()
    reset_button.draw()
    exit_button.draw()

    pygame.display.update()

    clock.tick(FRAMES_PER_SECOND)

pygame.quit()
sys.exit()