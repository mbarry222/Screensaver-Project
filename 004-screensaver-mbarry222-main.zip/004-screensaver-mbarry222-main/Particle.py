import pygame
class Particle:
    def __init__(self, window, window_width, window_height, loc, velocity, color=(255, 255, 255), weight=1):
        self.window = window
        self.window_width = window_width
        self.window_height = window_height
        self.x, self.y = loc
        self.vx, self.vy = velocity
        self.color = color
        self.weight = weight
        self.dead = False

    def update(self):
        self.x += self.vx
        self.y += self.vy

        if self.x < 0 or self.x > self.window_width or self.y < 0 or self.y > self.window_height:
            self.dead = True

    def draw(self):
        pygame.draw.circle(self.window, self.color, (int(self.x), int(self.y)), self.weight)

class Sun(Particle):
    def __init__(self, window, window_width, window_height, loc, color=(255, 255, 0), radius=50):
        super().__init__(window, window_width, window_height, loc, (0, 1), color=color, weight=radius)
        self.radius = radius

    def update(self):
        super().update()  # Update position

        r, g, b = self.color
        self.color = (r, max(g - 1, 0), max(b - 1, 0))  # Simulate setting sun effect

    def draw(self):
        pygame.draw.circle(self.window, self.color, (int(self.x), int(self.y)), self.radius)

class MovingObject(Particle):
    def __init__(self, window, window_width, window_height, loc, velocity, color, radius):
        super().__init__(window, window_width, window_height, loc, velocity, color=color, weight=radius)

    def update(self):
        super().update()

        if self.x - self.weight <= 0 or self.x + self.weight >= self.window_width:
            self.vx *= -1
        if self.y - self.weight <= 0 or self.y + self.weight >= self.window_height:
            self.vy *= -1