# My plan

For my screensaver, I plan to create an image of what appears to be a rising sun.

#background image of sky/ocean to create sunset scenery
    #https://pixabay.com/photos/bora-bora-french-polynesia-sunset-685303/